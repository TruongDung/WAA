package edu.mum.coffee.domain;

public enum ProductType {
	BREAKFAST,LUNCH,DINNER;
}
